《破碎余烬隐修会》· 第九卷人物志上一版顶部九图（原图备份）
历史来源：b6dd9ccb2640b4d5fb3016fd1058329031562e53（2026-11-15）
以下九张是当时独立画廊的原始文件，不是当前正文使用的 3:1 横幅；未做二次裁剪或压缩。

01-iserin.webp  伊瑟林·灰烬行者
来源：severed-ember/assets/portraits/revised-20261114/01-iserin-full.webp

02-alex.webp  阿历克斯·镜影
来源：severed-ember/assets/portraits/revised-20261114/02-alex-full.webp

03-aurek.webp  奥瑞克·寂静之言
来源：severed-ember/assets/portraits/approved-20261115/aurek-silent-word-20261115.webp

04-galeron.webp  加勒隆·虚空行者
来源：severed-ember/assets/portraits/revised-20261114/04-galeron-full.webp

05-sebastian.webp  塞巴斯蒂安·寂静之刃
来源：severed-ember/assets/portraits/revised-20261114/05-sebastian-full.webp

06-reginald.webp  雷金纳德·负井者
来源：severed-ember/assets/editorial-20261114-v2/16-reginald-half-phase.webp

07-severin.webp  塞维林·断索
来源：severed-ember/assets/portraits/revised-20261114/07-severin-full.webp

08-gavriel.webp  加弗里尔·井底之目
来源：severed-ember/assets/portraits/08-gavriel-full.webp

09-cole.webp  科尔·烬誓
来源：severed-ember/assets/portraits/revised-20261114/09-cole-full.webp
